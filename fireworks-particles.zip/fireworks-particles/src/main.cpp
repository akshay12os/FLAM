#include <GL/glew.h>
#include <GLFW/glfw3.h>
#include <cstdlib>
#include <cmath>
#include <vector>
#include <iostream>
#include <ctime>

const int MAX_PARTICLES = 1000;

struct Particle {
    float x, y;
    float vx, vy;
    float r, g, b, a;
    float life;
};

std::vector<Particle> particles;

void spawnBurst(float cx, float cy) {
    particles.clear();
    for (int i = 0; i < MAX_PARTICLES; ++i) {
        float angle = ((float)rand() / RAND_MAX) * 2.0f * M_PI;
        float speed = ((float)rand() / RAND_MAX) * 0.5f + 0.2f;

        Particle p;
        p.x = cx;
        p.y = cy;
        p.vx = cos(angle) * speed;
        p.vy = sin(angle) * speed;
        p.r = 1.0f;
        p.g = ((float)rand() / RAND_MAX);
        p.b = ((float)rand() / RAND_MAX);
        p.a = 1.0f;
        p.life = 1.0f;

        particles.push_back(p);
    }
}

void updateParticles(float dt) {
    for (auto& p : particles) {
        if (p.life > 0.0f) {
            p.life -= dt;
            p.x += p.vx * dt;
            p.y += p.vy * dt;
            p.vy -= 0.5f * dt; // gravity
            p.a -= dt;
        }
    }
}

void drawParticles() {
    glBegin(GL_POINTS);
    for (const auto& p : particles) {
        if (p.life > 0.0f) {
            glColor4f(p.r, p.g, p.b, p.a);
            glVertex2f(p.x, p.y);
        }
    }
    glEnd();
}

void mouse_callback(GLFWwindow* window, int button, int action, int mods) {
    if (button == GLFW_MOUSE_BUTTON_LEFT && action == GLFW_PRESS) {
        double xpos, ypos;
        int width, height;
        glfwGetCursorPos(window, &xpos, &ypos);
        glfwGetWindowSize(window, &width, &height);

        float x = (xpos / width) * 2.0f - 1.0f;
        float y = -((ypos / height) * 2.0f - 1.0f);
        spawnBurst(x, y);
    }
}

int main() {
    srand(time(nullptr));

    if (!glfwInit()) return -1;

    GLFWwindow* window = glfwCreateWindow(800, 600, "Fireworks Particle System", nullptr, nullptr);
    if (!window) {
        glfwTerminate();
        return -1;
    }

    glfwMakeContextCurrent(window);
    glewInit();

    glfwSetMouseButtonCallback(window, mouse_callback);

    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE); // Additive blending
    glPointSize(4.0f);

    glClearColor(0.0f, 0.0f, 0.1f, 1.0f); // dark blue background

    spawnBurst(0.0f, 0.0f); // Initial burst in center

    while (!glfwWindowShouldClose(window)) {
        glClear(GL_COLOR_BUFFER_BIT);

        updateParticles(0.016f); // ~60 FPS
        drawParticles();

        glfwSwapBuffers(window);
        glfwPollEvents();
    }

    glfwDestroyWindow(window);
    glfwTerminate();
    return 0;
}
